

-- HOSPITAL created by sobing
Config.DoorList['HOSPITAL-HOSPITAL'] = {
    authorizedJobs = { ['ambulance'] = 0 },
    locked = true,
    doorRate = 1.0,
    doors = {
        {objName = -770740285, objYaw = 160.00003051758, objCoords = vec3(328.624237, -585.201172, 43.327370)},
        {objName = -770740285, objYaw = 340.00003051758, objCoords = vec3(330.793976, -585.990906, 43.327370)}
    },
    cantUnlock = false,
    interactDistance = 3,
    items = { ['lockpick'] = 1 },
    doorType = 'double',
    svgDistance = 3,
}