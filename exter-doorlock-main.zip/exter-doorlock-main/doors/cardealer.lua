

-- -2051651622 created by liam16361
Config.DoorList['cardealer--2051651622'] = {
    cantUnlock = false,
    interactDistance = 2,
    doorRate = 1.0,
    passCode = '12345',
    objName = -2051651622,
    svgDistance = 7,
    locked = true,
    objCoords = vec3(-31.723524, -1101.846558, 26.572254),
    doorType = 'door',
    authorizedJobs = { ['cardealer'] = 0 },
}

-- 1417577297 created by liam16361
Config.DoorList['cardealer-1417577297'] = {
    cantUnlock = false,
    interactDistance = 2,
    doorRate = 1.0,
    doors = {
        {objName = 1417577297, objYaw = 340.00003051758, objCoords = vec3(-37.331127, -1108.873291, 26.719799)},
        {objName = 2059227086, objYaw = 340.00003051758, objCoords = vec3(-39.133663, -1108.218140, 26.719799)}
    },
    locked = true,
    doorType = 'double',
    authorizedJobs = { ['cardealer'] = 0 },
    svgDistance = 7,
}