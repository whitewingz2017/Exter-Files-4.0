

-- DSFGDSFG created by JeyJey
Config.DoorList['TEST-DSFGDSFG'] = {
    allAuthorized = true,
    interactDistance = 1,
    locked = true,
    doorRate = 1.0,
    doors = {
        {objName = 1417577297, objYaw = 250.00003051758, objCoords = vec3(-60.545818, -1094.748901, 26.888716)},
        {objName = 2059227086, objYaw = 250.00003051758, objCoords = vec3(-59.893024, -1092.951782, 26.883617)}
    },
    cantUnlock = false,
    doorType = 'double',
    svgDistance = 4,
}