

-- hospital created by sobing
Config.DoorList['hospital2-hospital'] = {
    authorizedJobs = { ['ambulance'] = 0 },
    locked = true,
    doorRate = 1.0,
    doors = {
        {objName = 220394186, objYaw = 69.767250061035, objCoords = vec3(299.906281, -584.054077, 43.441959)},
        {objName = 220394186, objYaw = 249.88534545898, objCoords = vec3(299.336609, -585.601318, 43.442272)}
    },
    cantUnlock = false,
    interactDistance = 3,
    items = { ['lockpick'] = 1 },
    doorType = 'double',
    svgDistance = 3,
}