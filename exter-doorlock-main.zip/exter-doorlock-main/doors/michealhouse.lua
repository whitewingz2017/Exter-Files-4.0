

-- entrancedoors created by liam16361
Config.DoorList['michealhouse-entrancedoors'] = {
    doorType = 'double',
    doors = {
        {objName = 159994461, objYaw = 291.00006103516, objCoords = vec3(-816.716003, 179.097961, 72.827377)},
        {objName = -1686014385, objYaw = 291.00006103516, objCoords = vec3(-816.106812, 177.510864, 72.827377)}
    },
    cantUnlock = false,
    doorRate = 1.0,
    locked = true,
    allAuthorized = true,
    svgDistance = 7,
    interactDistance = 2,
}

-- garageinsidedoor created by liam16361
Config.DoorList['michealhouse-garageinsidedoor'] = {
    fixText = false,
    cantUnlock = false,
    objName = -1563640173,
    objCoords = vec3(-806.281738, 186.024612, 72.624046),
    doorType = 'door',
    interactDistance = 2,
    locked = false,
    svgDistance = 7,
    doorRate = 1.0,
    allAuthorized = true,
    fixText = true
}