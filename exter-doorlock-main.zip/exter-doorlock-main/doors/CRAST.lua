

-- 201 created by STORMY
Config.DoorList['CRAST-201'] = {
    doorType = 'door',
    objCoords = vec3(-1536.942749, -530.645142, 47.901974),
    objName = 2011001180,
    locked = true,
    svgDistance = 1,
    doorRate = 1.0,
    interactDistance = 1,
    cantUnlock = false,
    fixText = false,
    allAuthorized = true,
}