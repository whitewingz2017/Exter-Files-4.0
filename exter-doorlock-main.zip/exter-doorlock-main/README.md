
# Exter-Doorlock

A modern doorlock script inspired by NoPixel 4.0, featuring an advanced UI and dynamic door configuration system for FiveM servers.

## 🧠 Features

- ✅ Interactive and sleek NoPixel 4.0-style UI
- 🔐 Comprehensive door locking system with multiple access authorization methods:
  - Job-based access
  - Gang-based access
  - Password protection
  - Citizen ID (Identifier) authorization
  - Item-based access
- 🔁 Dual door hash support (Door Hash 1 & 2)
- 📏 Adjustable SVG icon and interaction distances
- 🚪 Door options:
  - Locked
  - Lockpickable
  - Can't Unlock
  - Fix Text

## 📷 UI Preview

[tamp](https://github.com/user-attachments/assets/b546b82f-6010-42ea-a1b2-86ae98761638)


https://github.com/user-attachments/assets/482c69d8-ebd8-4ab5-9139-115c0bc43ce1


## ⚙️ How to Use

1. **Place the script inside your FiveM resources folder.**
2. **Add to `server.cfg`:**
   ```cfg
   ensure exter-doorlock
   ```
3. **In-game configuration:**
   - Fill in `Config File Name` (used to save the config)
   - Set door name and both door hashes
   - Choose the door type and required authorizations
   - Set SVG and interaction distances
4. **Click Submit to save and enable the doorlock**



## 🧱 Dependencies

- [ox_lib](https://overextended.dev/)
- [exter-lockpick](https://github.com/ExterCore/exter-lockpick)

## 💡 Notes

- Fully standalone and framework-compatible.

## 📞 Support

For issues or suggestions, contact the developer via Discord or GitHub.


© 2025 ExterFramework by CLTRALTDELETE
