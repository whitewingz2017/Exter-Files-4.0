local CodeID = {
    codeName = 'EXTER-CHAT NOPIXEL DESIGN 4.0',
    version = '1.0'
  }
  
  Citizen.CreateThread(function()
  print('[' .. CodeID.codeName .. '] v' .. CodeID.version .. ' sucessfully started!')
  end)