Config = {}

-- Choose between 'ESX' , 'QBCore' or 'NPBASE'
Config.Framework = 'QBCore'