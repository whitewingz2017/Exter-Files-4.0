Config = {
    ServerCallbacks = {}, -- Don't edit or change
    InvoiceJobs = { 
        -- Commission is the value at which the invoicing player will receive commission after the invoice is paid. For example, when an invoice of 5000 is paid, if the commission value is 5%, the player will receive 250.
        -- If the tax value is, for example, the invoice issuer entered 5000 in the invoice amount, if the tax value is also 5, the invoice amount will be 5250.
        -- If society is false when a bill is paid the player who invoiced this bill will get a commision
        ["police"] = {commision = 10, taxRate = 5, society = true},
        ["ambulance"] = {commision = 5, taxRate = 5, society = true},
        ["mechanic"] = {commision = 4, taxRate = 5, society = true}

        -- if you want to enter all the money and taxes into the boss menu
        --["police"] = {commision = 100, taxRate = 0, society = false},
        --["ambulance"] = {commision = 100, taxRate = 0, society = false},
        --["mechanic"] = {commision = 100, taxRate = 0, society = false}
    },
    MaxInvoiceValue = 999999,
    BillsMenu = {
        Command = "mybills",
        Keybinding = {
            Enable = true,
            Key = "F6",
            Description = "See bills/taxes"
        }
    },
    InvoiceMenu = {
        Command = "billing",
        Keybinding = {
            Enable = true,
            Key = "F7",
            Description = "Open invoice menu"
        }
    },
    AddMoneyManagement = function(account, amount) -- if you want to use the default
        exports['qb-banking']:AddMoney(account, amount)
    end
    --AddMoneyManagement = function(account, amount) -- if you want to enter all the money and taxes into the boss menu
    --    exports['qb-management']:AddMoney(account, amount)
    --end
}
