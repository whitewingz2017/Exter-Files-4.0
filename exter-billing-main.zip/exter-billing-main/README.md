# EXTER-BILLING
## [FREE] [QBCORE] BILLING SYSTEM AND TAXES LIKE NOPIXEL 4.0

![npx1](https://github.com/user-attachments/assets/f93d3c14-a0be-4f3b-899b-e26bbc8df7e9)
![npx2](https://github.com/user-attachments/assets/0ca56593-843a-4baf-b5ca-62c976bc19cf)
![npx3](https://github.com/user-attachments/assets/8dec114d-72f3-4386-9a97-7128fa413859)
![npx5](https://github.com/user-attachments/assets/60d73864-2f85-4c8d-a8c5-be02e0f55936)

## DEPENDECIES

[qb-banking](https://github.com/qbcore-framework/qb-banking)

[qb-management](https://github.com/qbcore-framework/qb-management)

[qb-core](https://github.com/qbcore-framework/qb-core)

[TextUI](https://github.com/ExterCore/exter-textui)
