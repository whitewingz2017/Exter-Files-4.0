# EXTER-RADIO
## RADIO SCRIPT LIKE NOPIXEL 4.0 STANDALONE

![exter](https://github.com/user-attachments/assets/d1749374-f10d-49b3-8d07-684fc756bae2)
