fx_version 'cerulean'
lua54 'yes'
game 'gta5'

author 'sobing4413'

version '1.1'

client_scripts {
	'client/main.lua'
}

files {
    'html/**',
}

ui_page 'html/index.html'
