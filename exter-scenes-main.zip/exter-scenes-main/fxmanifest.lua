fx_version "cerulean"
game "gta5"
lua54 "yes"

author "sobing"

description "EXTER-SCENE NOPIXEL DESIGN 4.0"

version '1.0'

ui_page 'web/build/index.html'

client_script "client/**/*"

server_script "server/**/*"

files {
	'web/build/index.html',
	'web/build/**/*',
}