Config = {
    Menu = {
        Command = "carmenu", 
        Keybind = "F11", 
        Align = "bottom-center" -- top-center, bottom-center, top-left, top-right, bottom-left, bottom-right
    },
    AlarmDuration = 30000, -- Second x 10000
}