# exter-banking
## [STANDALONE] EXTER-BANKING | BANKING SCRIPT LIKE NOPIXEL 4.0

### This script requires a dependency or bridge to a framework. This script is standalone

## PREVIEW VIDEO

[video](https://streamable.com/blpbc2)

## PREVIEW IMAGES
### V2.0
![bank2](https://github.com/user-attachments/assets/19334d72-7f65-495f-b977-a4f70a04e05f)
![bank1](https://github.com/user-attachments/assets/40b59aef-762e-4a92-8d89-3cb2ccb8feab)


## PREVIEW IMAGES
### V1.3
![sample1](https://github.com/user-attachments/assets/02f65277-2542-4310-ac00-9af07a039a58)
![sample2](https://github.com/user-attachments/assets/19258489-e3dd-4a97-9c18-cf18a2038172)
![sample3](https://github.com/user-attachments/assets/13daad5a-e6c3-4b6d-b622-f33ddfe36065)

## changelog
- fixed exit button
- Gui Update

## DEPENDENCIES 

[exter_core](https://github.com/ExterCore/exter_core)

## NOTED
### YOU JUST NEED TO DRAG AND DROP THE SCRIPT INTO YOUR FILE SERVER. IF YOU HAVE PROBLEMS OR ERRORS WITH THE BANKING SCRIPT. SEPARATE EXTER-CORE SCRIPTS WITH BANKING FROM THE SAME FOLDER
